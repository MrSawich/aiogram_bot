from aiogram import F, Router, types
from aiogram.types import Message, CallbackQuery, InputFile, FSInputFile
from aiogram.filters import CommandStart, Command
import app.keyboards as kb

router = Router()

actors = dict()

@router.message(CommandStart())
async def cmd_start(message: Message):
    await message.answer(f"Привет, {message.from_user.first_name}!", reply_markup=kb.main)
    if message.chat.id not in actors:
        actors[message.chat.id] = [f"{message.from_user.first_name} {message.from_user.last_name}", 1000, 10, 0]
    print(actors)

@router.message(Command("admin"))
async def cmd_admin(message: Message):
    await message.answer("Вы авторизованы как администратор", reply_markup=kb.admin)


@router.message(F.text == "Начать игру")
async def start(message: Message):
    with open(r"C:/Users/Andrey/PycharmProjects/aiogram_bot/text/prequel.txt", "r", encoding="utf-8") as prequel:
        prequel_txt = prequel.read()
    with open(r"C:/Users/Andrey/PycharmProjects/aiogram_bot/text/etap1.txt", "r", encoding="utf-8") as file:
        etap_txt = file.read()
    a, b, c = etap_txt.split("#", 3)
    c = c.replace("\n", "")
    await message.answer(prequel_txt)
    await message.answer(c)
    await message.answer_photo(FSInputFile(r"C:/Users/Andrey/PycharmProjects/aiogram_bot/photo/etap1.png"), reply_markup=kb.choice)

@router.message(F.text == "Правила игры")
async def rule(message: Message):
    with open(r"C:/Users/Andrey/PycharmProjects/aiogram_bot/text/rule.txt", "r", encoding="utf-8") as rule:
        rule_txt = rule.read()
    await message.answer(rule_txt, reply_markup=kb.start)


@router.callback_query(F.data == "ch1")
async def ch1(callback: CallbackQuery):
    with open(r"C:/Users/Andrey/PycharmProjects/aiogram_bot/text/answer1.txt", "r", encoding="utf-8") as file:
        etap_txt = file.read()
        await callback.message.answer(etap_txt)
        await callback.message.answer_photo(FSInputFile(r"C:/Users/Andrey/PycharmProjects/aiogram_bot/photo/1.jpg"),
                                   reply_markup=kb.game_2)
        await callback.message.edit_reply_markup(reply_markup=None)

@router.callback_query(F.data == "ch2")
async def ch2(callback: CallbackQuery):
    await callback.message.answer("Неверно")
    await callback.message.edit_reply_markup(reply_markup=None)

@router.callback_query(F.data == "game_2")
async def game_2(callback: CallbackQuery):
    with open(r"C:/Users/Andrey/PycharmProjects/aiogram_bot/text/etap2.txt", "r", encoding="utf-8") as file:
        etap_txt = file.read()
    a, b, c = etap_txt.split("#", 3)
    c = c.replace("\n", "")
    await callback.message.answer(c)
    await callback.message.answer_photo(FSInputFile(r"C:/Users/Andrey/PycharmProjects/aiogram_bot/photo/etap2.png"),
                               reply_markup=kb.choice2)

@router.callback_query(F.data == "ch3")
async def ch3(callback: CallbackQuery):
    with open(r"C:/Users/Andrey/PycharmProjects/aiogram_bot/text/answer3.txt", "r", encoding="utf-8") as file:
        etap_txt = file.read()
    await callback.message.answer(etap_txt)
    await callback.message.answer_photo(FSInputFile(r"C:/Users/Andrey/PycharmProjects/aiogram_bot/photo/3.jpg"), reply_markup=kb.game_3)
    await callback.message.edit_reply_markup(reply_markup=None)

@router.callback_query(F.data == "game_3")
async def game_3(callback: CallbackQuery):
    with open(r"C:/Users/Andrey/PycharmProjects/aiogram_bot/text/etap3.txt", "r", encoding="utf-8") as file:
        etap_txt = file.read()
    a, b, c = etap_txt.split("#", 3)
    c = c.replace("\n", "")
    await callback.message.answer(c)
    await callback.message.answer_photo(FSInputFile(r"C:/Users/Andrey/PycharmProjects/aiogram_bot/photo/etap3.png"),reply_markup=kb.choice3)

@router.callback_query(F.data == "ch5")
async def ch5(callback: CallbackQuery):
    with open(r"C:/Users/Andrey/PycharmProjects/aiogram_bot/text/answer5.txt", "r", encoding="utf-8") as file:
        etap_txt = file.read()
    await callback.message.answer(etap_txt)
    await callback.message.answer_photo(FSInputFile(r"C:/Users/Andrey/PycharmProjects/aiogram_bot/photo/4.jpg"), reply_markup=kb.game_4)
    await callback.message.edit_reply_markup(reply_markup=None)

@router.callback_query(F.data == "game_4")
async def game_4(callback: CallbackQuery):
    with open(r"C:/Users/Andrey/PycharmProjects/aiogram_bot/text/etap4.txt", "r", encoding="utf-8") as file:
        etap_txt = file.read()
    a, b, c = etap_txt.split("#", 3)
    c = c.replace("\n", "")
    await callback.message.answer(c)
    await callback.message.answer_photo(FSInputFile(r"C:/Users/Andrey/PycharmProjects/aiogram_bot/photo/etap4.png"),reply_markup=kb.choice4)

@router.callback_query(F.data == "ch7")
async def ch7(callback: CallbackQuery):
    with open(r"C:/Users/Andrey/PycharmProjects/aiogram_bot/text/answer7.txt", "r", encoding="utf-8") as file:
        etap_txt = file.read()
    await callback.message.answer(etap_txt)
    await callback.message.answer_photo(FSInputFile(r"C:/Users/Andrey/PycharmProjects/aiogram_bot/photo/7.jpg"), reply_markup=kb.game_5)
    await callback.message.edit_reply_markup(reply_markup=None)

@router.callback_query(F.data == "game_5")
async def game_5(callback: CallbackQuery):
    with open(r"C:/Users/Andrey/PycharmProjects/aiogram_bot/text/etap5.txt", "r", encoding="utf-8") as file:
        etap_txt = file.read()
    a, b, c = etap_txt.split("#", 3)
    c = c.replace("\n", "")
    await callback.message.answer(c)
    await callback.message.answer_photo(FSInputFile(r"C:/Users/Andrey/PycharmProjects/aiogram_bot/photo/etap5.png"),reply_markup=kb.choice5)

@router.callback_query(F.data == "ch9")
async def ch9(callback: CallbackQuery):
    with open(r"C:/Users/Andrey/PycharmProjects/aiogram_bot/text/answer9.txt", "r", encoding="utf-8") as file:
        etap_txt = file.read()
    await callback.message.answer(etap_txt)
    await callback.message.answer_photo(FSInputFile(r"C:/Users/Andrey/PycharmProjects/aiogram_bot/photo/9.jpg"), reply_markup=kb.final)
    await callback.message.edit_reply_markup(reply_markup=None)

@router.callback_query(F.data == "final")
async def ch9(callback: CallbackQuery):
    with open(r"C:/Users/Andrey/PycharmProjects/aiogram_bot/text/final.txt", "r", encoding="utf-8") as file:
        etap_txt = file.read()
    await callback.message.answer(etap_txt)
    await callback.message.answer_photo(FSInputFile(r"C:/Users/Andrey/PycharmProjects/aiogram_bot/photo/final_1.jpg"))