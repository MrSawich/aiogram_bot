import asyncio
import logging
from aiogram.client.session.aiohttp import AiohttpSession
from aiogram import Bot, Dispatcher
from app.handlers import router


async def main():
    #session = AiohttpSession(proxy="http://proxy.server:3128")
    bot = Bot(token="7037566831:AAHsoFZo0sEAaEnUWcWL8CZkMWZQCPnuEVo")#, session=session)
    dp = Dispatcher()
    dp.include_router(router)
    await dp.start_polling(bot)

if __name__ == "__main__":
    #logging.basicConfig(level=logging.INFO)
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("Бот выключен")
